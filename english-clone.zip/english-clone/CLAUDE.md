# CLAUDE.md — LinguaFree (clone Duolingo gratuit, spécialisé anglais A1→C2)

## CONTEXTE PROJET
- Développeur : Loïc BONI
- Objectif : clone fonctionnel de Duolingo, 100% gratuit, spécialisé anglais, niveaux CECRL A1 à C2
- Stack : React + Vite (front) / Supabase (auth + DB Postgres) / API Claude pour génération d'exercices IA
- Structure déjà scaffoldée : package.json, vite.config.js, supabase/schema.sql, src/data/curriculum.js, src/lib/gamification.js, src/lib/aiExercise.js, api/generate-exercise.js

## RÈGLES DE CODE (non négociables)
- Jamais de clé API en dur dans le code → toujours `.env` + variables d'environnement
- Toute requête Supabase sensible passe par Row Level Security (RLS), jamais de bypass côté client
- Composants React fonctionnels + hooks uniquement (pas de classes)
- Un composant = un fichier = une responsabilité
- Commenter en français, code (variables/fonctions) en anglais
- Aucun texte inventé : si une donnée/API n'est pas vérifiable, le signaler explicitement
- Après chaque fonctionnalité : `npm run build` doit passer sans erreur avant de continuer

## BOUCLE DE DÉVELOPPEMENT (à exécuter en autonomie)

Répète ce cycle pour chaque fonctionnalité de la liste ci-dessous, dans l'ordre :

1. **PLAN** — Annoncer en une ligne la fonctionnalité en cours et lister les fichiers à créer/modifier
2. **IMPLEMENT** — Écrire le code complet (pas de `// TODO` ni de stubs vides)
3. **VERIFY** — Lancer `npm run build` (ou `npm run dev` en dry-run) ; corriger toute erreur avant de continuer
4. **SELF-REVIEW** — Relire le code produit : sécurité RLS, gestion d'erreurs, cohérence avec le style existant
5. **COMMIT** — `git add -A && git commit -m "feat: <fonctionnalité>"` (créer le repo git si absent)
6. **NEXT** — Passer automatiquement à la fonctionnalité suivante de la liste, sans attendre de confirmation, sauf si bloqué par une ambiguïté fonctionnelle réelle (dans ce cas : poser UNE question précise et attendre)

Ne jamais s'arrêter pour dire "voulez-vous que je continue ?" — enchaîner jusqu'à la fin de la liste ou jusqu'à un vrai blocage technique.

## LISTE DES FONCTIONNALITÉS À DÉVELOPPER (ordre de priorité)

- [ ] `src/components/Auth.jsx` — inscription/connexion Supabase (email + mot de passe), création auto du profil
- [ ] `src/components/Navbar.jsx` — navigation + affichage XP/streak/coeurs en temps réel
- [ ] `src/components/LessonPath.jsx` — parcours visuel des unités par niveau (utilise `curriculum.js`), verrouillage progressif
- [ ] `src/components/Exercise.jsx` — moteur d'exercice générique (QCM, trous, traduction), gestion des coeurs perdus, appel à `completeLesson()`
- [ ] `src/components/StreakWidget.jsx` — affichage visuel du streak + calendrier des 7 derniers jours
- [ ] `src/components/Leaderboard.jsx` — classement des utilisateurs par XP (requête Supabase triée)
- [ ] `src/components/Dashboard.jsx` — écran d'accueil post-connexion, assemble Navbar + LessonPath + StreakWidget
- [ ] `src/App.jsx` — routing complet (react-router-dom) : /login, /dashboard, /lesson/:id, /leaderboard
- [ ] `src/styles.css` — design cohérent (palette, typographie), mobile-first
- [ ] Script de seed (`supabase/seed.sql`) — remplir `lessons` et `exercises` avec un contenu réel A1→C2 (minimum 3 exercices par leçon)
- [ ] Intégration IA : brancher `aiExercise.js` sur `Exercise.jsx` pour générer des exercices additionnels à la volée
- [ ] Système de coeurs : recharge automatique après un délai (ex. 1 coeur/4h) via `refillHearts()`
- [ ] Tests manuels : parcours complet inscription → leçon → XP → streak → leaderboard
- [ ] `README.md` final avec instructions de déploiement (Vercel + Supabase)

## COMMANDE DE DÉMARRAGE

Une fois ce fichier lu, démarrer immédiatement la boucle sur la première fonctionnalité non cochée, sans demander de validation préalable.
